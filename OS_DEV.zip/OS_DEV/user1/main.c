#include "lib.h"
#include "stdint.h"

int main(void)
{
    while (1) {
        printf("\n hello there from user 1\n");
        waitu();
    }
    return 0;
}
