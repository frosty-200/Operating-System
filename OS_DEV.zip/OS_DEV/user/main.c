#include "lib.h"

int main(void)
{
    printf("\nprocess starts\n");
    return 0;
}
